<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DataTables;
use App\Models\Trucking;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class TruckingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    } 

    public function index(Request $request)
    {
        $data = [
            'count_user' => Trucking::latest()->count(),
            'menu'       => 'menu.v_menu_admin',
            'content'    => 'content.view_trucking',
            'title'    => 'Trucking'
        ];

        if ($request->ajax()) {
            $q_trucking = Trucking::select('*')->orderByDesc('created_at');
            return Datatables::of($q_trucking)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
     
                        $btn = '<div data-toggle="tooltip"  data-id="'.$row->trucking_id.'" data-original-title="Edit" class="btn btn-sm btn-icon btn-outline-success btn-circle mr-2 edit editTrucking"><i class=" fi-rr-edit"></i></div>';
                        $btn = $btn.' <div data-toggle="tooltip"  data-id="'.$row->trucking_id.'" data-original-title="Delete" class="btn btn-sm btn-icon btn-outline-danger btn-circle mr-2 deleteTrucking"><i class="fi-rr-trash"></i></div>';
 
                         return $btn;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }

        return view('layouts.v_template',$data);
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        Trucking::updateOrCreate(['trucking_id' => $request->trucking_id],
                [
                 'trucking_name' => $request->trucking_name,
                 'vehicle_plate' => $request->vehicle_plate,
                 'contact_person' => $request->contact_person,
                 'contact_number' => $request->contact_number,
                ]);        

        return response()->json(['success'=>'User saved successfully!']);
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $Trucking = Trucking::find($id);
        return response()->json($Trucking);

    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        Trucking::find($id)->delete();

        return response()->json(['success'=>'Trucking deleted!']);
    }
}
