<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DataTables;
use App\Models\Customer;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class CustomerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    } 

    public function index(Request $request)
    {
        $data = [
            'count_user' => Customer::latest()->count(),
            'menu'       => 'menu.v_menu_admin',
            'content'    => 'content.view_customer',
            'title'    => 'Customer'
        ];

        if ($request->ajax()) {
            $q_customer = Customer::select('*')->orderByDesc('created_at');
            return Datatables::of($q_customer)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
						
						$btn = '<div data-toggle="tooltip"  data-id="'.$row->customer_id.'" data-original-title="View" class="btn btn-sm btn-icon btn-outline-success btn-circle mr-2 view viewCustomer"><i class=" fi-rr-eye"></i></div>';
                        $btn = $btn.' <div data-toggle="tooltip"  data-id="'.$row->customer_id.'" data-original-title="Edit" class="btn btn-sm btn-icon btn-outline-success btn-circle mr-2 edit editCustomer"><i class=" fi-rr-edit"></i></div>';
                        $btn = $btn.' <div data-toggle="tooltip"  data-id="'.$row->customer_id.'" data-original-title="Delete" class="btn btn-sm btn-icon btn-outline-danger btn-circle mr-2 deleteCustomer"><i class="fi-rr-trash"></i></div>';
 
                         return $btn;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }

        return view('layouts.v_template',$data);
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        Customer::updateOrCreate(['customer_id' => $request->customer_id],
                [
                 'customer_name' => $request->customer_name,
                 'contact_number' => $request->contact_number,
                 'address' => $request->address,
                ]);        

        return response()->json(['success'=>'Customer saved successfully!']);
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $Customer = Customer::find($id);
        return response()->json($Customer);

    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        Customer::find($id)->delete();

        return response()->json(['success'=>'Customer deleted!']);
    }
}
