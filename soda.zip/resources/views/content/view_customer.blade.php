<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>{{$title}}</h2>
                <div class="d-flex flex-row-reverse"><button
                        class="btn btn-sm btn-pill btn-outline-primary font-weight-bolder" id="createNewCustomer"><i
                            class="fas fa-plus"></i>add data </button></div>
            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table" id="tableUser">
                            <thead class="font-weight-bold text-center">
                                <tr>
                                    {{-- <th>No.</th> --}}
                                    <th>Customer ID</th>
                                    <th>Customer Name</th>
                                    <th>Contact Number</th>
									<th>Address</th>
                                    <th style="width:150px;">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                {{-- @foreach ($customer as $r_customers)
                                    <tr>
                                <td>{{$r_customers->customer_id}}</td>
                                <td>{{$r_customers->customer_name}}</td>
                                <td>{{$r_customers->contact_number}}</td>
                                <td>{{$r_customers->address}}</td>
                                <td>
                                    <div class="btn btn-success editCustomer" data-id="{{$r_customers->id}}">Edit</div>
                                    <div class="btn btn-danger deleteCustomer" data-id="{{$r_customers->id}}">Delete</div>
                                </td>
                                </tr>
                                @endforeach --}}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal-->
<div class="modal fade" id="modal-customer" data-backdrop="static" tabindex="-1" role="dialog"
    aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white" id="exampleModalLabel">Customer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i aria-hidden="true" class="ki ki-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="formCustomer" name="formCustomer">
                    <div class="form-group">
                        <input type="text" name="customer_name" class="form-control" id="customer_name" placeholder="Customer Name" required><br>
						<input type="text" name="contact_number" class="form-control" id="contact_number" placeholder="Contac Number" required><br>
						<input type="text" name="address" class="form-control" id="address" placeholder="Address" required><br>
						<input type="hidden" name="customer_id" id="customer_id" value="">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary font-weight-bold" id="saveBtn">Save changes</button>
            </div>
        </div>
    </div>
</div>


<!-- Modal-->
<div class="modal fade" id="modal-view-customer" data-backdrop="static" tabindex="-1" role="dialog"
    aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white" id="exampleModalLabel">Customer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i aria-hidden="true" class="ki ki-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="formUser" name="formUser">
                    <div class="form-group">

                        <input type="text" name="name" class="form-control" id="name" placeholder="Nama" required><br>
                        <input type="email" name="email" class="form-control" id="email" placeholder="email" required><br>
                        <select name="level" class="form-control" id="level">
                            <option value="-">Pilih Level</option>
                            <option value="1">Operator</option>
                            <option value="2">Member</option>
                        </select><br>
                        <input type="text" name="password" class="form-control" placeholder="password"><br>
                       
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary font-weight-bold" id="saveBtn">Save changes</button>
            </div>
        </div>
    </div>
</div>


@push('scripts')
<script>
    $('document').ready(function () {
        // success alert
        function swal_success() {
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: 'Your work has been saved',
                showConfirmButton: false,
                timer: 1000
            })
        }
        // error alert
        function swal_error() {
            Swal.fire({
                position: 'centered',
                icon: 'error',
                title: 'Something goes wrong !',
                showConfirmButton: true,
            })
        }
        // table serverside
        var table = $('#tableUser').DataTable({
            processing: false,
            serverSide: true,
            ordering: false,
            dom: 'Bfrtip',
            buttons: [
             
            ],
            ajax: "{{ route('customer.index') }}",
            columns: [{
                    data: 'customer_id',
                    name: 'customer_id'
                },
                {
                    data: 'customer_name',
                    name: 'customer_name'
                },
                {
                    data: 'contact_number',
                    name: 'contact_number'
                },
				 {
                    data: 'address',
                    name: 'address'
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                },
            ]
        });
        
        // csrf token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // initialize btn add
        $('#createNewCustomer').click(function () {
            $('#saveBtn').val("create customer");
            $('#customer_id').val('');
            $('#formUser').trigger("reset");
            $('#modal-customer').modal('show');
        });
		
		// initialize btn view
        $('body').on('click', '.viewCustomer', function () {
            var customer_id = $(this).data('id');
            $.get("{{route('users.index')}}" + '/' + customer_id + '/edit', function (data) {
                $('#saveBtn').val("edit-user");
                $('#modal-view-customer').modal('show');
                $('#customer_id').val(data.id);
                $('#name').val(data.name);
                $('#email').val(data.email);
                $('#level').val(data.level);
            })
        });
		
        // initialize btn edit
        $('body').on('click', '.editCustomer', function () {
            var customer_id = $(this).data('id');
            $.get("{{route('customer.index')}}" + '/' + customer_id + '/edit', function (data) {
                $('#saveBtn').val("edit-user");
                $('#modal-customer').modal('show');
                $('#customer_id').val(data.customer_id);
                $('#customer_name').val(data.customer_name);
				$('#contact_number').val(data.contact_number);
				$('#address').val(data.address);
				$('#customer_id').val(data.customer_id);
				
            })
        });
        // initialize btn save
        $('#saveBtn').click(function (e) {
            e.preventDefault();
            $(this).html('Save');

            $.ajax({
                data: $('#formCustomer').serialize(),
                url: "{{ route('customer.store') }}",
                type: "POST",
                dataType: 'json',
                success: function (data) {

                    $('#formCustomer').trigger("reset");
                    $('#modal-customer').modal('hide');
                    swal_success();
                    table.draw();

                },
                error: function (data) {
                    swal_error();
                    $('#saveBtn').html('Save Changes');
                }
            });

        });
        // initialize btn delete
        $('body').on('click', '.deleteCustomer', function () {
            var customer_id = $(this).data("id");

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "DELETE",
                        url: "{{route('customer.store')}}" + '/' + customer_id,
                        success: function (data) {
                            swal_success();
                            table.draw();
                        },
                        error: function (data) {
                            swal_error();
                        }
                    });
                }
            })
        });

   

    });
	

</script>
@endpush
